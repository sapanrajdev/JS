function fibonacci() {

}

fibonacci(10);